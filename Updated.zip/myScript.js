let tog = 0;
function onClick()
{
    if(tog == 0)
        {
            alert("Toggle is 0 will be set to 1");
            tog = 1;
        }
    else
        {
            alert("Toggle is 1 will be set to 0");
            tog = 0;
        }
    document.getElementById("recipeBtn").style.color="pink";
}

function searchClick()
{
    const searchBar = document.getElementById('searchBar');
    alert(searchBar.value);
}

function recipePage()
{
    location.replace("Recipe.html")
}